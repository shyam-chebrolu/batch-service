package com.example.batch.entity;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.AttributeConverter;

import java.util.List;
import java.util.Map;

public class JpaJsonConverter implements AttributeConverter<Object, String> {

    private final static ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String convertToDatabaseColumn(Object attribute) {
        try {
            return objectMapper.writeValueAsString(attribute);
        } catch (Exception e) {
            throw new IllegalArgumentException(e);
        }
    }

    @Override
    public Object convertToEntityAttribute(String dbData) {
        try {
            // Try map first
            return objectMapper.readValue(dbData, Map.class);
        } catch (Exception e) {
            try {
                return objectMapper.readValue(dbData, List.class);
            } catch (Exception ex) {
                throw new IllegalArgumentException(ex);
            }
        }
    }
}
