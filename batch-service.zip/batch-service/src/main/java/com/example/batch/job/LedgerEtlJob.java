package com.example.batch.job;

import org.quartz.JobExecutionContext;
import org.springframework.stereotype.Component;

import java.util.Map;


@Component
public class LedgerEtlJob extends BaseQuartzJob {

    @Override
    protected void doExecute(JobExecutionContext ctx, Map<String, Object> params) throws Exception {
        System.out.printf("LedgerEtlJob");
    }
}
