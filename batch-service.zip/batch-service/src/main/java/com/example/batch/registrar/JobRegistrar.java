package com.example.batch.registrar;

import com.example.batch.entity.BatchJobCalendar;
import com.example.batch.entity.BatchJobDefinition;
import com.example.batch.repository.BatchJobCalendarRepository;
import com.example.batch.repository.BatchJobDefinitionRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.quartz.*;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class JobRegistrar {

    private final Scheduler scheduler;
    private final BatchJobDefinitionRepository jobDefinitionRepository;
    private final BatchJobCalendarRepository jobCalendarRepository;

    @PostConstruct
    public void init() throws Exception {
        log.info("Registering enabled jobs from DB...");
        List<BatchJobDefinition> jobs = jobDefinitionRepository.findByEnabledTrue();

        for (BatchJobDefinition job : jobs) {
            registerJob(job);
        }
    }

    public void registerJob(BatchJobDefinition job) throws Exception {
        String jobKeyStr = buildJobKey(job);
        JobKey jobKey = JobKey.jobKey(jobKeyStr);

        if (scheduler.checkExists(jobKey)) {
            log.info("Job {} already registered. Skipping.", jobKeyStr);
            return;
        }

        // Build JobDetail
        JobDetail jobDetail = JobBuilder.newJob((Class<? extends Job>) Class.forName(job.getJobClass()))
                .withIdentity(jobKey)
                .usingJobData("params", job.getParameters())
                .usingJobData("tenantId", job.getTenantId())
                .build();

        // Build Trigger with Cron and Calendar
        TriggerBuilder<CronTrigger> triggerBuilder = TriggerBuilder.newTrigger()
                .withIdentity(jobKeyStr + "-trigger")
                .withSchedule(CronScheduleBuilder.cronSchedule(job.getCronExpression()));

        // Apply calendar if defined
        if (job.getCalendarName() != null) {
            BatchJobCalendar calendar = findCalendar(job.getTenantId(), job.getCalendarName());
            if (calendar != null) {
                org.quartz.Calendar quartzCalendar = buildQuartzCalendar(calendar);
                scheduler.addCalendar(calendar.getCalendarName(), quartzCalendar, false, false);
                triggerBuilder.modifiedByCalendar(calendar.getCalendarName());
            }
        }

        CronTrigger trigger = triggerBuilder.build();

        scheduler.scheduleJob(jobDetail, trigger);
        log.info("Registered job: {} with cron: {}", jobKeyStr, job.getCronExpression());
    }

    private String buildJobKey(BatchJobDefinition job) {
        return job.getTenantId() + ":" + job.getJobId() + "-v" + job.getVersion();
    }

    private BatchJobCalendar findCalendar(String tenantId, String calendarName) {
        // Try tenant-specific calendar first
        BatchJobCalendar calendar = jobCalendarRepository.findByTenantIdAndCalendarName(tenantId, calendarName);

        if (calendar != null) {
            return calendar;
        }

        // Fallback to global calendar
        return jobCalendarRepository.findByTenantIdAndCalendarName("GLOBAL", calendarName);
    }


    private org.quartz.Calendar buildQuartzCalendar(BatchJobCalendar calendar) {
        // For simplicity, assume we use AnnualCalendar for excluded dates
        org.quartz.impl.calendar.AnnualCalendar quartzCalendar = new org.quartz.impl.calendar.AnnualCalendar();
        if (calendar.getExcludedDates() != null) {
            for (String dateStr : calendar.getExcludedDates()) {
                try {
                    java.util.Calendar cal = java.util.Calendar.getInstance();
                    String[] parts = dateStr.split("-");
                    cal.set(java.util.Calendar.MONTH, Integer.parseInt(parts[1]) - 1); // month 0-based
                    cal.set(java.util.Calendar.DAY_OF_MONTH, Integer.parseInt(parts[2]));
                    quartzCalendar.setDayExcluded(cal, true);
                } catch (Exception e) {
                    log.warn("Invalid excluded date {} for calendar {}", dateStr, calendar.getCalendarName());
                }
            }
        }
        return quartzCalendar;
    }
}
