package com.example.batch.repository;


import com.example.batch.entity.BatchJobDefinition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BatchJobDefinitionRepository extends JpaRepository<BatchJobDefinition, Long> {

    List<BatchJobDefinition> findByEnabledTrue();

    // Optional: find jobs by tenant
    List<BatchJobDefinition> findByTenantIdAndEnabledTrue(String tenantId);
}
