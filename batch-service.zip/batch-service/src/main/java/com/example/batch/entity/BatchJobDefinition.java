package com.example.batch.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Map;

@Entity
@Table(name = "batch_job_definition")
@Data
public class BatchJobDefinition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String tenantId;
    private String jobId;
    private Integer version;
    private String description;
    private String jobClass;
    private String cronExpression;
    private Boolean enabled;
    private String parameters;
    private String calendarName;
}
