package com.example.batch.job;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import java.util.Map;

@Slf4j
public abstract class BaseQuartzJob implements Job {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public final void execute(JobExecutionContext ctx) throws JobExecutionException {
        String jobKey = ctx.getJobDetail().getKey().toString();
        log.info("Starting job: {}", jobKey);

        try {
            Map<String, Object> params = getJobParams(ctx);
            doExecute(ctx, params);
            log.info("Completed job: {}", jobKey);
        } catch (Exception e) {
            log.error("Job {} failed with exception", jobKey, e);
            throw new JobExecutionException(e, true); // retry if configured
        }
    }

    /**
     * Concrete job classes implement this method
     *
     * @param ctx Quartz context
     * @param params Deserialized job parameters
     */
    protected abstract void doExecute(JobExecutionContext ctx, Map<String, Object> params) throws Exception;

    /**
     * Extracts parameters JSON string from JobDataMap and deserializes it
     */
    @SuppressWarnings("unchecked")
    protected Map<String, Object> getJobParams(JobExecutionContext ctx) throws Exception {
        String paramsJson = ctx.getMergedJobDataMap().getString("params");
        if (paramsJson == null || paramsJson.isBlank()) {
            return Map.of();
        }
        return objectMapper.readValue(paramsJson, new TypeReference<>() {});
    }
}
