package com.example.batch.repository;

import com.example.batch.entity.BatchJobCalendar;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BatchJobCalendarRepository extends JpaRepository<BatchJobCalendar, Long> {

    List<BatchJobCalendar> findByTenantId(String tenantId);

    BatchJobCalendar findByTenantIdAndCalendarName(String tenantId, String calendarName);
}
