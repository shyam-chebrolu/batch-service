package com.example.batch.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data
@Entity
@Table(name = "batch_job_calendar")
public class BatchJobCalendar {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String tenantId;
    private String calendarName;
    private String calendarType;

    @Convert(converter = JpaJsonConverter.class)
    private List<String> excludedDates;

    private String parentCalendar;
    private String description;

}
