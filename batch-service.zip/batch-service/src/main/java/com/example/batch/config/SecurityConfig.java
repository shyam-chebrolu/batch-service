package com.example.batch.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableMethodSecurity  // enables @PreAuthorize
public class SecurityConfig {

    // In-memory user for testing
    @Bean
    public InMemoryUserDetailsManager userDetailsService() {
        UserDetails admin = User.withUsername("admin")
                .password("{noop}admin123")  // {noop} = plain password
                .roles("BATCH_ADMIN")
                .build();
        return new InMemoryUserDetailsManager(admin);
    }

    // Basic HTTP security config
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable()) // disable CSRF for testing POST requests
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/batch/**").hasRole("BATCH_ADMIN")
                        .anyRequest().authenticated())
                .httpBasic(httpBasic -> {}); // enable basic auth

        return http.build();
    }
}
