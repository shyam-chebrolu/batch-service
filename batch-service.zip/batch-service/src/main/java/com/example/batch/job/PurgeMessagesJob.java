package com.example.batch.job;

import org.quartz.JobExecutionContext;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Map;

@Component
public class PurgeMessagesJob extends BaseQuartzJob {

    @Override
    protected void doExecute(JobExecutionContext ctx, Map<String, Object> params) throws Exception {
        // Extract parameters with defaults
        int retentionDays = (int) params.getOrDefault("retentionDays", 30);

        // Example purge logic
        LocalDateTime cutoff = LocalDateTime.now().minusDays(retentionDays);

        System.out.printf("Purging messages older than %s%n", cutoff);

        // Example: log tenant info
        String tenantId = ctx.getMergedJobDataMap().getString("tenantId");
        System.out.printf("Tenant: %s%n", tenantId);
    }
}
