
package com.example.batch.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.quartz.Scheduler;
import org.quartz.JobKey;
import org.springframework.stereotype.Controller;

@RestController
@RequestMapping("/api/batch")
public class BatchAdminController {
    private final Scheduler scheduler;
    public BatchAdminController(Scheduler scheduler) { this.scheduler = scheduler; }

    @PostMapping("/jobs/{jobKey}/run")
//    @PreAuthorize("hasRole('BATCH_ADMIN')")
    public void runNow(@PathVariable String jobKey) throws Exception {
        scheduler.triggerJob(JobKey.jobKey(jobKey));
    }
}
