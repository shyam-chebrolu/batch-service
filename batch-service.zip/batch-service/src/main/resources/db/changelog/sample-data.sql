
-- -------------------------------
-- Optional: Insert sample data
-- -------------------------------
-- Global Calendar
INSERT INTO batch_job_calendar (tenant_id, calendar_name, calendar_type, excluded_dates, parent_calendar, description)
VALUES
('global', 'global-holidays', 'HOLIDAY', '["2026-01-01","2026-07-04","2026-12-25"]', NULL, 'Global US Federal Holidays');

-- Tenant 1 Calendars
INSERT INTO batch_job_calendar (tenant_id, calendar_name, calendar_type, excluded_dates, parent_calendar, description)
VALUES
('tenant1', 'tenant1-holidays', 'HOLIDAY', '["2026-11-26"]', 'global-holidays', 'Tenant 1 additional holidays'),
('tenant1', 'tenant1-business-hours', 'BUSINESS_HOURS', '["2026-01-01","2026-07-04"]', NULL, 'Tenant 1 business hours');

-- Tenant 1 Job Definitions
INSERT INTO batch_job_definition (tenant_id, job_id, version, description, job_class, cron_expression, enabled, parameters, calendar_name)
VALUES
('tenant1', 'purge_messages', 1, 'Purge old messages', 'com.example.batch.job.PurgeMessagesJob', '0 0 2 * * ?', true, '{"retentionDays":30}', 'tenant1-holidays'),
('tenant1', 'ledger_etl', 1, 'Run Ledger ETL', 'com.example.batch.job.LedgerEtlJob', '0 30 1 * * ?', true, '{}', 'tenant1-business-hours');
