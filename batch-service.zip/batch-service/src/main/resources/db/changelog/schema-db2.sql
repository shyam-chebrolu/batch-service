-- =========================
-- Batch Job Definitions
-- =========================
CREATE TABLE batch_job_definition (
                                      tenant_id        VARCHAR(50) NOT NULL,
                                      job_id           VARCHAR(50) NOT NULL,
                                      version          INT NOT NULL,
                                      description      VARCHAR(1024),
                                      job_class        VARCHAR(200) NOT NULL,
                                      cron_expression  VARCHAR(100),
                                      enabled          SMALLINT NOT NULL, -- 0 = false, 1 = true
                                      parameters       CLOB,              -- JSON stored as string
                                      created_at       TIMESTAMP DEFAULT CURRENT TIMESTAMP,
                                      updated_at       TIMESTAMP DEFAULT CURRENT TIMESTAMP,
                                      PRIMARY KEY (tenant_id, job_id, version)
);

-- =========================
-- Batch Job Execution Audit
-- =========================
CREATE TABLE batch_job_execution (
                                     execution_id   BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                                     tenant_id      VARCHAR(50),
                                     job_id         VARCHAR(50),
                                     version        INT,
                                     start_time     TIMESTAMP,
                                     end_time       TIMESTAMP,
                                     status         VARCHAR(20),
                                     error_message  CLOB,
                                     instance_id    VARCHAR(100)
);

-- =========================
-- Batch Job Dead Letter Queue
-- =========================
CREATE TABLE batch_job_dlq (
                               dlq_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                               job_id        VARCHAR(50),
                               version       INT,
                               failed_at     TIMESTAMP,
                               payload       CLOB,
                               error_message CLOB
);

-- =========================
-- Batch Job SLA
-- =========================
CREATE TABLE batch_job_sla (
                               job_id            VARCHAR(50),
                               version           INT,
                               max_duration_sec  INT,
                               alert_target      VARCHAR(512)
);

-- =========================
-- Batch Job Calendar
-- =========================
CREATE TABLE batch_job_calendar (
                                    calendar_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                                    tenant_id        VARCHAR(50) NOT NULL,
                                    calendar_name    VARCHAR(100) NOT NULL,
                                    calendar_type    VARCHAR(50) NOT NULL,  -- e.g., BUSINESS_HOURS, HOLIDAY
                                    definition       CLOB,                   -- JSON or serialized calendar rules
                                    created_at       TIMESTAMP DEFAULT CURRENT TIMESTAMP,
                                    updated_at       TIMESTAMP DEFAULT CURRENT TIMESTAMP,
                                    UNIQUE(tenant_id, calendar_name)
);

-- =========================
-- Batch Job Dependency
-- =========================
CREATE TABLE batch_job_dependency (
                                      dependency_id  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                                      tenant_id      VARCHAR(50) NOT NULL,
                                      job_id         VARCHAR(50) NOT NULL,
                                      depends_on_job_id VARCHAR(50) NOT NULL,
                                      version        INT NOT NULL
);
