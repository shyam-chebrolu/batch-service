-- ==========================================================
-- Schema for Enterprise Batch Platform
-- PostgreSQL
-- Includes tables, primary keys, unique constraints, foreign keys
-- ==========================================================

-- -----------------------------
-- Table: batch_job_definition
-- -----------------------------
CREATE TABLE batch_job_definition (
                                      id BIGSERIAL PRIMARY KEY,
                                      tenant_id VARCHAR(50) NOT NULL,
                                      job_id VARCHAR(50) NOT NULL,
                                      version INT NOT NULL,
                                      description TEXT,
                                      job_class VARCHAR(200) NOT NULL,
                                      cron_expression VARCHAR(100),
                                      enabled BOOLEAN NOT NULL DEFAULT TRUE,
                                      parameters JSONB,
                                      calendar_name VARCHAR(100),
                                      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Unique constraint for FK references and versioned jobs
ALTER TABLE batch_job_definition
    ADD CONSTRAINT uq_batch_job_definition UNIQUE (tenant_id, job_id, version);


-- -----------------------------
-- Table: batch_job_execution
-- -----------------------------
CREATE TABLE batch_job_execution (
                                     execution_id BIGSERIAL PRIMARY KEY,
                                     tenant_id VARCHAR(50) NOT NULL,
                                     job_id VARCHAR(50) NOT NULL,
                                     version INT NOT NULL,
                                     start_time TIMESTAMP,
                                     end_time TIMESTAMP,
                                     status VARCHAR(20),
                                     error_message TEXT,
                                     instance_id VARCHAR(100)
);

-- -----------------------------
-- Table: batch_job_calendar
-- -----------------------------
CREATE TABLE batch_job_calendar (
                                    id BIGSERIAL PRIMARY KEY,
                                    tenant_id VARCHAR(50),
                                    calendar_name VARCHAR(100) NOT NULL,
                                    calendar_type VARCHAR(50),
                                    excluded_dates JSONB,
                                    parent_calendar VARCHAR(100),
                                    description TEXT
);

-- -----------------------------
-- Table: batch_job_dependency
-- -----------------------------
CREATE TABLE batch_job_dependency (
                                      id BIGSERIAL PRIMARY KEY,
                                      tenant_id VARCHAR(50) NOT NULL,
                                      job_id VARCHAR(50) NOT NULL,
                                      depends_on_job VARCHAR(50) NOT NULL,
                                      depends_on_ver INT NOT NULL,
                                      CONSTRAINT fk_batch_job_def FOREIGN KEY (tenant_id, depends_on_job, depends_on_ver)
                                          REFERENCES batch_job_definition(tenant_id, job_id, version)
                                          ON DELETE CASCADE
);

-- -----------------------------
-- Optional: Indexes for faster lookups
-- -----------------------------
CREATE INDEX idx_batch_job_def_enabled ON batch_job_definition (enabled);
CREATE INDEX idx_batch_job_exec_tenant_job ON batch_job_execution (tenant_id, job_id, version);
CREATE INDEX idx_batch_job_dep_tenant_job ON batch_job_dependency (tenant_id, job_id);

